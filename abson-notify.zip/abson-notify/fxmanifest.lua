fx_version 'cerulean'
game 'gta5'

description "simple notify"


client_scripts {
	'client/main.lua'
}

ui_page 'ui/index.html'

files {
    'ui/**'
}

export 'SendNoti'