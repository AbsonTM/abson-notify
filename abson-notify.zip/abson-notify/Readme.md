###Thank you for downloading Visul Core Notify!###
Visul Core Notify is standalone.

If you have any questions related to this resource, feel free to join our Discord: https://discord.gg/54HYtcsnzN